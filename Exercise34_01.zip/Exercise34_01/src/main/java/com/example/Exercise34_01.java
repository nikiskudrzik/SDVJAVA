package com.example;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.sql.*;

public class Exercise34_01 extends Application {

    private static final String DB_URL = "jdbc:sqlite:staff.db";

    private final TextField tfId = new TextField();
    private final TextField tfLastName = new TextField();
    private final TextField tfFirstName = new TextField();
    private final TextField tfMi = new TextField();
    private final TextField tfAddress = new TextField();
    private final TextField tfCity = new TextField();
    private final TextField tfState = new TextField();
    private final TextField tfTelephone = new TextField();
    private final TextField tfEmail = new TextField();

    private final Label lblStatus = new Label(" ");

    private Connection conn;
    private PreparedStatement psView;
    private PreparedStatement psInsert;
    private PreparedStatement psUpdate;

    @Override
    public void start(Stage stage) throws Exception {
        initDb();

        tfMi.setPrefColumnCount(2);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(8);
        grid.setPadding(new Insets(12));

        int r = 0;
        grid.add(new Label("ID"), 0, r); grid.add(tfId, 1, r++);
        grid.add(new Label("Last Name"), 0, r); grid.add(tfLastName, 1, r++);
        grid.add(new Label("First Name"), 0, r); grid.add(tfFirstName, 1, r++);
        grid.add(new Label("MI"), 0, r); grid.add(tfMi, 1, r++);
        grid.add(new Label("Address"), 0, r); grid.add(tfAddress, 1, r++);
        grid.add(new Label("City"), 0, r); grid.add(tfCity, 1, r++);
        grid.add(new Label("State"), 0, r); grid.add(tfState, 1, r++);
        grid.add(new Label("Telephone"), 0, r); grid.add(tfTelephone, 1, r++);
        grid.add(new Label("Email"), 0, r); grid.add(tfEmail, 1, r++);

        ColumnConstraints c0 = new ColumnConstraints();
        c0.setMinWidth(95);
        ColumnConstraints c1 = new ColumnConstraints();
        c1.setHgrow(Priority.ALWAYS);
        grid.getColumnConstraints().addAll(c0, c1);

        Button btnView = new Button("View");
        Button btnInsert = new Button("Insert");
        Button btnUpdate = new Button("Update");
        Button btnClear = new Button("Clear");

        btnView.setOnAction(e -> view());
        btnInsert.setOnAction(e -> insert());
        btnUpdate.setOnAction(e -> update());
        btnClear.setOnAction(e -> clear());

        HBox buttons = new HBox(12, btnView, btnInsert, btnUpdate, btnClear);
        buttons.setAlignment(Pos.CENTER);
        buttons.setPadding(new Insets(0, 12, 8, 12));

        lblStatus.setPadding(new Insets(0, 12, 12, 12));

        VBox root = new VBox(6, grid, buttons, lblStatus);

        stage.setTitle("Exercise 34.1 - Staff Table");
        stage.setScene(new Scene(root, 720, 520));
        stage.show();
    }

    // connect + create table + prep SQL
    private void initDb() throws SQLException {
        conn = DriverManager.getConnection(DB_URL);

        // same table SQL as the book
        String createSql = """
                CREATE TABLE IF NOT EXISTS Staff (
                  id CHAR(9) NOT NULL,
                  lastName VARCHAR(15),
                  firstName VARCHAR(15),
                  mi CHAR(1),
                  address VARCHAR(20),
                  city VARCHAR(20),
                  state CHAR(2),
                  telephone CHAR(10),
                  email VARCHAR(40),
                  PRIMARY KEY (id)
                );
                """;

        try (Statement st = conn.createStatement()) {
            st.execute(createSql);
        }

        psView = conn.prepareStatement("SELECT * FROM Staff WHERE id = ?");
        psInsert = conn.prepareStatement(
                "INSERT INTO Staff (id,lastName,firstName,mi,address,city,state,telephone,email) " +
                "VALUES (?,?,?,?,?,?,?,?,?)"
        );
        psUpdate = conn.prepareStatement(
                "UPDATE Staff SET lastName=?,firstName=?,mi=?,address=?,city=?,state=?,telephone=?,email=? " +
                "WHERE id=?"
        );
    }

    // View: show record by ID
    private void view() {
        String id = tfId.getText().trim();
        if (id.isEmpty()) { setStatus("Enter an ID."); return; }

        try {
            psView.setString(1, id);
            try (ResultSet rs = psView.executeQuery()) {
                if (!rs.next()) {
                    clearNonId();
                    setStatus("Record not found.");
                    return;
                }
                tfLastName.setText(n(rs.getString("lastName")));
                tfFirstName.setText(n(rs.getString("firstName")));
                tfMi.setText(n(rs.getString("mi")));
                tfAddress.setText(n(rs.getString("address")));
                tfCity.setText(n(rs.getString("city")));
                tfState.setText(n(rs.getString("state")));
                tfTelephone.setText(n(rs.getString("telephone")));
                tfEmail.setText(n(rs.getString("email")));
                setStatus("Record loaded.");
            }
        } catch (SQLException ex) {
            setStatus("View failed: " + ex.getMessage());
        }
    }

    // Insert: add new record
    private void insert() {
        String id = tfId.getText().trim();
        if (id.isEmpty()) { setStatus("ID is required."); return; }

        try {
            psView.setString(1, id);
            try (ResultSet rs = psView.executeQuery()) {
                if (rs.next()) { setStatus("ID already exists. Use Update."); return; }
            }

            psInsert.setString(1, id);
            psInsert.setString(2, v(tfLastName.getText()));
            psInsert.setString(3, v(tfFirstName.getText()));
            psInsert.setString(4, mi(tfMi.getText()));
            psInsert.setString(5, v(tfAddress.getText()));
            psInsert.setString(6, v(tfCity.getText()));
            psInsert.setString(7, state(tfState.getText()));
            psInsert.setString(8, phone(tfTelephone.getText()));
            psInsert.setString(9, v(tfEmail.getText()));

            psInsert.executeUpdate();
            setStatus("Inserted.");
        } catch (SQLException ex) {
            setStatus("Insert failed: " + ex.getMessage());
        }
    }

    // Update: change record for ID
    private void update() {
        String id = tfId.getText().trim();
        if (id.isEmpty()) { setStatus("ID is required."); return; }

        try {
            psView.setString(1, id);
            try (ResultSet rs = psView.executeQuery()) {
                if (!rs.next()) { setStatus("Record not found. Use Insert."); return; }
            }

            psUpdate.setString(1, v(tfLastName.getText()));
            psUpdate.setString(2, v(tfFirstName.getText()));
            psUpdate.setString(3, mi(tfMi.getText()));
            psUpdate.setString(4, v(tfAddress.getText()));
            psUpdate.setString(5, v(tfCity.getText()));
            psUpdate.setString(6, state(tfState.getText()));
            psUpdate.setString(7, phone(tfTelephone.getText()));
            psUpdate.setString(8, v(tfEmail.getText()));
            psUpdate.setString(9, id);

            int rows = psUpdate.executeUpdate();
            setStatus(rows == 1 ? "Updated." : "Update affected " + rows + " rows.");
        } catch (SQLException ex) {
            setStatus("Update failed: " + ex.getMessage());
        }
    }

    // Clear: empty fields
    private void clear() {
        tfId.clear();
        clearNonId();
        setStatus("Cleared.");
    }

    private void clearNonId() {
        tfLastName.clear();
        tfFirstName.clear();
        tfMi.clear();
        tfAddress.clear();
        tfCity.clear();
        tfState.clear();
        tfTelephone.clear();
        tfEmail.clear();
    }

    private void setStatus(String msg) {
        lblStatus.setText(msg);
    }

    private static String n(String s) { return s == null ? "" : s; }

    private static String v(String s) {
        if (s == null) return null;
        String t = s.trim();
        return t.isEmpty() ? null : t;
    }

    private static String mi(String s) {
        String t = v(s);
        if (t == null) return null;
        return t.length() > 1 ? t.substring(0, 1) : t;
    }

    private static String state(String s) {
        String t = v(s);
        if (t == null) return null;
        t = t.toUpperCase();
        return t.length() > 2 ? t.substring(0, 2) : t;
    }

    private static String phone(String s) {
        String t = v(s);
        if (t == null) return null;
        String digits = t.replaceAll("\\D+", "");
        if (digits.length() > 10) digits = digits.substring(digits.length() - 10);
        return digits;
    }

    @Override
    public void stop() throws Exception {
        super.stop();
        try { if (psView != null) psView.close(); } catch (SQLException ignored) {}
        try { if (psInsert != null) psInsert.close(); } catch (SQLException ignored) {}
        try { if (psUpdate != null) psUpdate.close(); } catch (SQLException ignored) {}
        try { if (conn != null) conn.close(); } catch (SQLException ignored) {}
    }

    public static void main(String[] args) {
        launch(args);
    }
}