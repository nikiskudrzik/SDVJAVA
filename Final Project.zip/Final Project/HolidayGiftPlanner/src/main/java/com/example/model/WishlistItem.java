package com.example.model;

/**
 * Represents a gift idea that has not yet been purchased.
 */
public class WishlistItem extends GiftItem {

    private int priority; // 1 (high) to 5 (low)
    private boolean purchased;

    public WishlistItem(String id, String name, double price,
                        String store, String notes, int priority) {
        super(id, name, price, store, notes);
        setPriority(priority);
        this.purchased = false;
    }

    public int getPriority() {
        return priority;
    }

    public boolean isPurchased() {
        return purchased;
    }

    public void setPriority(int priority) {
        if (priority < 1 || priority > 5) {
            throw new IllegalArgumentException("Priority must be between 1 and 5.");
        }
        this.priority = priority;
    }

    public void setPurchased(boolean purchased) {
        this.purchased = purchased;
    }

    @Override
    public String toString() {
        return super.toString() +
                ", priority=" + priority +
                ", purchased=" + purchased;
    }
}