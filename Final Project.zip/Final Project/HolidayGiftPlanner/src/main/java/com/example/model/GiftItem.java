package com.example.model;

/**
 * Abstract base class for all gift items.
 */
public abstract class GiftItem {

    protected String id;
    protected String name;
    protected double price;
    protected String store;
    protected String notes;

    public GiftItem(String id, String name, double price, String store, String notes) {
        this.id = id;
        this.name = name;
        setPrice(price); // validation
        this.store = store;
        this.notes = notes;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public String getStore() {
        return store;
    }

    public String getNotes() {
        return notes;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(double price) {
        if (price < 0) {
            throw new IllegalArgumentException("Price cannot be negative.");
        }
        this.price = price;
    }

    public void setStore(String store) {
        this.store = store;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public boolean isValid() {
        return id != null && !id.isEmpty()
                && name != null && !name.isEmpty()
                && price >= 0;
    }

    @Override
    public String toString() {
        return "GiftItem{id='" + id + "', name='" + name +
                "', price=" + price + ", store='" + store +
                "', notes='" + notes + "'}";
    }
}
