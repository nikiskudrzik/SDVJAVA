package com.example.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a person receiving gifts.
 */
public class Recipient {

    private String id;
    private String firstName;
    private String lastName;
    private String relationship;
    private List<GiftItem> gifts;

    public Recipient(String id, String firstName,
                     String lastName, String relationship) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.relationship = relationship;
        this.gifts = new ArrayList<>();
    }

    public String getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getRelationship() {
        return relationship;
    }

    public List<GiftItem> getGifts() {
        return gifts;
    }

    public void addGift(GiftItem gift) {
        gifts.add(gift);
    }

    public void removeGiftById(String giftId) {
        gifts.removeIf(g -> g.getId().equals(giftId));
    }

    public GiftItem findGiftById(String giftId) {
        return gifts.stream()
                .filter(g -> g.getId().equals(giftId))
                .findFirst()
                .orElse(null);
    }

    public double getTotalPlannedCost() {
        return gifts.stream()
                .mapToDouble(GiftItem::getPrice)
                .sum();
    }

    public double getTotalSpent() {
        return gifts.stream()
                .filter(g -> g instanceof PurchasedItem)
                .mapToDouble(GiftItem::getPrice)
                .sum();
    }

    public boolean isValid() {
        return id != null && !id.isEmpty()
                && firstName != null && !firstName.isEmpty();
    }

    @Override
    public String toString() {
        return firstName + " " + lastName +
                " (" + relationship + ")";
    }
}
