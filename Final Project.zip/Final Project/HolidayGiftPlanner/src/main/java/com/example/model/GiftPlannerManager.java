package com.example.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Main manager class for the gift planner.
 */
public class GiftPlannerManager {

    private List<Recipient> recipients;
    private String dataFilePath;

    public GiftPlannerManager(String dataFilePath) {
        this.dataFilePath = dataFilePath;
        this.recipients = new ArrayList<>();
    }

    public List<Recipient> getRecipients() {
        return recipients;
    }

    public void addRecipient(Recipient recipient) {
        recipients.add(recipient);
    }

    public void removeRecipientById(String recipientId) {
        recipients.removeIf(r -> r.getId().equals(recipientId));
    }

    public Recipient findRecipientById(String recipientId) {
        return recipients.stream()
                .filter(r -> r.getId().equals(recipientId))
                .findFirst()
                .orElse(null);
    }

    public double getOverallPlannedCost() {
        return recipients.stream()
                .mapToDouble(Recipient::getTotalPlannedCost)
                .sum();
    }

    public double getOverallSpent() {
        return recipients.stream()
                .mapToDouble(Recipient::getTotalSpent)
                .sum();
    }
}
