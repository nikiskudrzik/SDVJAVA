package com.example.model;

/**
 * Represents a gift that has been purchased.
 */
public class PurchasedItem extends GiftItem {

    private String purchaseDate; // YYYY-MM-DD
    private String paymentMethod;
    private boolean wrapped;

    public PurchasedItem(String id, String name, double price,
                         String store, String notes,
                         String purchaseDate, String paymentMethod) {
        super(id, name, price, store, notes);
        this.purchaseDate = purchaseDate;
        this.paymentMethod = paymentMethod;
        this.wrapped = false;
    }

    public String getPurchaseDate() {
        return purchaseDate;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public boolean isWrapped() {
        return wrapped;
    }

    public void setPurchaseDate(String purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public void setWrapped(boolean wrapped) {
        this.wrapped = wrapped;
    }

    @Override
    public String toString() {
        return super.toString() +
                ", purchaseDate='" + purchaseDate +
                "', paymentMethod='" + paymentMethod +
                "', wrapped=" + wrapped;
    }
}
