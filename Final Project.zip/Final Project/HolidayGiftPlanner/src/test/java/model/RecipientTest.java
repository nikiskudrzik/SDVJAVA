package com.example.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import com.example.model.*;

class RecipientTest {

    @Test
    void testAddGift() {
        Recipient r = new Recipient("1", "John", "Doe", "Friend");
        WishlistItem item = new WishlistItem("g1", "Watch", 100, "Amazon", "", 2);

        r.addGift(item);

        assertEquals(1, r.getGifts().size());
    }

    @Test
    void testTotalSpent() {
        Recipient r = new Recipient("1", "John", "Doe", "Friend");
        PurchasedItem item = new PurchasedItem("g2", "Shoes", 80, "Nike", "", "2025-12-01", "Card");

        r.addGift(item);

        assertEquals(80, r.getTotalSpent());
    }

    @Test
    void testFindGift() {
        Recipient r = new Recipient("1", "John", "Doe", "Friend");
        WishlistItem item = new WishlistItem("g3", "Book", 20, "Barnes", "", 1);
        r.addGift(item);

        assertNotNull(r.findGiftById("g3"));
    }
}
