package com.example.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PurchasedItemTest {

    @Test
    void constructor_setsFields_andDefaultWrappedFalse() {
        PurchasedItem p = new PurchasedItem("p1", "Shoes", 80.0, "Nike", "Size 10",
                "2025-12-01", "Card");

        assertEquals("p1", p.getId());
        assertEquals("Shoes", p.getName());
        assertEquals(80.0, p.getPrice(), 0.0001);
        assertEquals("Nike", p.getStore());
        assertEquals("Size 10", p.getNotes());

        assertEquals("2025-12-01", p.getPurchaseDate());
        assertEquals("Card", p.getPaymentMethod());

        // default in our class design
        assertFalse(p.isWrapped());
    }

    @Test
    void setWrapped_updatesValue() {
        PurchasedItem p = new PurchasedItem("p1", "Shoes", 80.0, "Nike", "",
                "2025-12-01", "Card");

        p.setWrapped(true);
        assertTrue(p.isWrapped());

        p.setWrapped(false);
        assertFalse(p.isWrapped());
    }

    @Test
    void setPurchaseDate_updatesValue() {
        PurchasedItem p = new PurchasedItem("p1", "Shoes", 80.0, "Nike", "",
                "2025-12-01", "Card");

        p.setPurchaseDate("2025-12-24");
        assertEquals("2025-12-24", p.getPurchaseDate());
    }

    @Test
    void setPaymentMethod_updatesValue() {
        PurchasedItem p = new PurchasedItem("p1", "Shoes", 80.0, "Nike", "",
                "2025-12-01", "Card");

        p.setPaymentMethod("Cash");
        assertEquals("Cash", p.getPaymentMethod());
    }

    @Test
    void inheritsPriceValidation_negativePriceThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> new PurchasedItem("p1", "Shoes", -0.01, "Nike", "",
                        "2025-12-01", "Card"))
