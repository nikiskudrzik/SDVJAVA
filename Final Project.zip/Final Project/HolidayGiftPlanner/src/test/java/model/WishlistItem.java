package com.example.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class WishlistItemTest {

    @Test
    void constructor_setsFields_andDefaultPurchasedFalse() {
        WishlistItem w = new WishlistItem("w1", "Headphones", 40.0, "Amazon", "Black", 3);

        assertEquals("w1", w.getId());
        assertEquals("Headphones", w.getName());
        assertEquals(40.0, w.getPrice(), 0.0001);
        assertEquals("Amazon", w.getStore());
        assertEquals("Black", w.getNotes());
        assertEquals(3, w.getPriority());

        // default in our class design
        assertFalse(w.isPurchased());
    }

    @Test
    void setPurchased_updatesValue() {
        WishlistItem w = new WishlistItem("w1", "Headphones", 40.0, "Amazon", "", 3);

        w.setPurchased(true);
        assertTrue(w.isPurchased());

        w.setPurchased(false);
        assertFalse(w.isPurchased());
    }

    @Test
    void setPriority_acceptsValidRange() {
        WishlistItem w = new WishlistItem("w1", "Headphones", 40.0, "Amazon", "", 3);

        w.setPriority(1);
        assertEquals(1, w.getPriority());

        w.setPriority(5);
        assertEquals(5, w.getPriority());
    }

    @Test
    void setPriority_throwsException_whenOutOfRange() {
        WishlistItem w = new WishlistItem("w1", "Headphones", 40.0, "Amazon", "", 3);

        assertThrows(IllegalArgumentException.class, () -> w.setPriority(0));
        assertThrows(IllegalArgumentException.class, () -> w.setPriority(6));
    }

    @Test
    void constructor_throwsException_whenPriorityOutOfRange() {
        assertThrows(IllegalArgumentException.class,
                () -> new WishlistItem("w1", "Headphones", 40.0, "Amazon", "", 0));

        assertThrows(IllegalArgumentException.class,
                () -> new WishlistItem("w1", "Headphones", 40.0, "Amazon", "", 6));
    }

    @Test
    void inheritsPriceValidation_negativePriceThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> new WishlistItem("w1", "Headphones", -1.0, "Amazon", "", 3));
    }
}
