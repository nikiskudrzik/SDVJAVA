package edu.skudrzik;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.util.Objects;

public class Exercise14_01 extends Application {

    private Image load(String path) {
        return new Image(Objects.requireNonNull(
                getClass().getResourceAsStream(path),
                "Missing resource: " + path
        ));
    }

    @Override
    public void start(Stage stage) {
        GridPane pane = new GridPane();

        pane.add(new ImageView(load("/image/uk.gif")),    0, 0);
        pane.add(new ImageView(load("/image/china.gif")), 1, 0);
        pane.add(new ImageView(load("/image/ca.gif")),    0, 1);
        pane.add(new ImageView(load("/image/us.gif")),    1, 1);

        stage.setTitle("Exercise 14.1");
        stage.setScene(new Scene(pane));
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}