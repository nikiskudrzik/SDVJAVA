import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Exercise16_17 extends Application {

    @Override
    public void start(Stage primaryStage) {
        Text text = new Text("Show Colors");
        text.setFont(Font.font(24));

        // Sliders: 0..1 for red/green/blue/opacity
        Slider slRed = createSlider();
        Slider slGreen = createSlider();
        Slider slBlue = createSlider();
        Slider slOpacity = createSlider();
        slOpacity.setValue(1.0); // start fully visible

        // Labels + sliders in a grid
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(12);
        grid.setPadding(new Insets(15));

        grid.add(new Label("Red"), 0, 0);
        grid.add(slRed, 1, 0);

        grid.add(new Label("Green"), 0, 1);
        grid.add(slGreen, 1, 1);

        grid.add(new Label("Blue"), 0, 2);
        grid.add(slBlue, 1, 2);

        grid.add(new Label("Opacity"), 0, 3);
        grid.add(slOpacity, 1, 3);

        // Top title
        Label title = new Label("Show Colors");
        title.setFont(Font.font(18));
        HBox top = new HBox(title);
        top.setAlignment(Pos.CENTER);
        top.setPadding(new Insets(10));

        // Put the text in the center
        BorderPane pane = new BorderPane();
        pane.setTop(top);
        pane.setCenter(new HBox(text));
        BorderPane.setAlignment(pane.getCenter(), Pos.CENTER);
        pane.setBottom(grid);

        // Update text color whenever any slider changes
        Runnable updateColor = () -> text.setFill(new Color(
                slRed.getValue(),
                slGreen.getValue(),
                slBlue.getValue(),
                slOpacity.getValue()
        ));

        slRed.valueProperty().addListener((obs, oldV, newV) -> updateColor.run());
        slGreen.valueProperty().addListener((obs, oldV, newV) -> updateColor.run());
        slBlue.valueProperty().addListener((obs, oldV, newV) -> updateColor.run());
        slOpacity.valueProperty().addListener((obs, oldV, newV) -> updateColor.run());

        updateColor.run(); 

        Scene scene = new Scene(pane, 420, 260);
        primaryStage.setTitle("Exercise16_17");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private Slider createSlider() {
        Slider slider = new Slider(0, 1, 0);
        slider.setShowTickLabels(true);
        slider.setShowTickMarks(true);
        slider.setMajorTickUnit(0.25);
        slider.setMinorTickCount(4);
        slider.setBlockIncrement(0.01);
        slider.setPrefWidth(280);
        return slider;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
