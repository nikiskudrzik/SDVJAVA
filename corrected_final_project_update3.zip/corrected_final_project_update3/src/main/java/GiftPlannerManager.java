import java.io.*;
import java.util.ArrayList;

public class GiftPlannerManager {
    private ArrayList<Recipient> recipients;
    private String dataFilePath;

    public GiftPlannerManager(String dataFilePath) {
        this.dataFilePath = dataFilePath;
        this.recipients = new ArrayList<>();
    }

    public Recipient[] getRecipients() {
        return recipients.toArray(new Recipient[0]);
    }

    public void addRecipient(Recipient recipient) {
        if (recipient != null && recipient.isValid()) {
            recipients.add(recipient);
        }
    }

    public void removeRecipientById(String recipientId) {
        if (recipientId == null) return;

        for (int i = 0; i < recipients.size(); i++) {
            if (recipientId.equals(recipients.get(i).getId())) {
                recipients.remove(i);
                return;
            }
        }
    }

    public Recipient findRecipientById(String recipientId) {
        if (recipientId == null) return null;

        for (Recipient r : recipients) {
            if (recipientId.equals(r.getId())) return r;
        }
        return null;
    }

    public double getOverallPlannedCost() {
        double total = 0;
        for (Recipient r : recipients) total += r.getTotalPlannedCost();
        return total;
    }

    public double getOverallSpent() {
        double total = 0;
        for (Recipient r : recipients) total += r.getTotalSpent();
        return total;
    }

    public void saveToFile() throws IOException {
        if (dataFilePath == null || dataFilePath.trim().isEmpty()) return;

        try (PrintWriter out = new PrintWriter(new FileWriter(dataFilePath))) {
            for (Recipient r : recipients) {
                out.println("RECIPIENT|" + safe(r.getId()) + "|" + safe(r.getFirstName()) + "|"
                        + safe(r.getLastName()) + "|" + safe(r.getRelationship()));

                for (GiftItem g : r.getGifts()) {
                    if (g instanceof WishlistItem) {
                        WishlistItem w = (WishlistItem) g;
                        out.println("WISH|" + safe(r.getId()) + "|" + safe(w.getId()) + "|"
                                + safe(w.getName()) + "|" + w.getPrice() + "|" + safe(w.getStore()) + "|"
                                + safe(w.getNotes()) + "|" + w.getPriority() + "|" + w.isPurchased());
                    } else if (g instanceof PurchasedItem) {
                        PurchasedItem p = (PurchasedItem) g;
                        out.println("PURCHASED|" + safe(r.getId()) + "|" + safe(p.getId()) + "|"
                                + safe(p.getName()) + "|" + p.getPrice() + "|" + safe(p.getStore()) + "|"
                                + safe(p.getNotes()) + "|" + safe(p.getPurchaseDate()) + "|"
                                + safe(p.getPaymentMethod()) + "|" + p.isWrapped());
                    }
                }
            }
        }
    }

    public void loadFromFile() throws IOException {
        recipients.clear();
        if (dataFilePath == null || dataFilePath.trim().isEmpty()) return;

        File file = new File(dataFilePath);
        if (!file.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\\|", -1);
                if (parts.length == 0) continue;

                if (parts[0].equals("RECIPIENT") && parts.length >= 5) {
                    Recipient r = new Recipient(parts[1], parts[2], parts[3], parts[4]);
                    recipients.add(r);
                } else if (parts[0].equals("WISH") && parts.length >= 9) {
                    Recipient r = findRecipientById(parts[1]);
                    if (r == null) continue;

                    double price = parseDoubleSafe(parts[4]);
                    int priority = parseIntSafe(parts[7]);

                    WishlistItem w = new WishlistItem(parts[2], parts[3], price, parts[5], parts[6], priority);
                    w.setPurchased(Boolean.parseBoolean(parts[8]));
                    r.addGift(w);

                } else if (parts[0].equals("PURCHASED") && parts.length >= 10) {
                    Recipient r = findRecipientById(parts[1]);
                    if (r == null) continue;

                    double price = parseDoubleSafe(parts[4]);

                    PurchasedItem p = new PurchasedItem(parts[2], parts[3], price, parts[5], parts[6],
                            parts[7], parts[8]);
                    p.setWrapped(Boolean.parseBoolean(parts[9]));
                    r.addGift(p);
                }
            }
        }
    }

    private String safe(String s) {
        return (s == null) ? "" : s.replace("|", "/").trim();
    }

    private double parseDoubleSafe(String s) {
        try { return Double.parseDouble(s); }
        catch (Exception e) { return 0; }
    }

    private int parseIntSafe(String s) {
        try { return Integer.parseInt(s); }
        catch (Exception e) { return 1; }
    }
}
