public class GiftItemTest {
    public static void main(String[] args) {
        System.out.println("=== GiftItem / Subclass Tests ===");

        WishlistItem w = new WishlistItem("W1", "Legos", 39.99, "Target", "Star Wars set", 2);
        System.out.println("Wishlist created: " + w);
        System.out.println("Valid? " + w.isValid());

        w.setPrice(-10); // should clamp to 0
        System.out.println("After negative price, price = " + w.getPrice());

        w.setPriority(99); // should clamp to 5
        System.out.println("After bad priority, priority = " + w.getPriority());

        PurchasedItem p = new PurchasedItem("P1", "Headphones", 79.50, "Best Buy", "", "2026-12-01", "Card");
        p.setWrapped(true);
        System.out.println("Purchased created: " + p);
        System.out.println("Wrapped? " + p.isWrapped());

        System.out.println("=== Done ===");
    }
}
