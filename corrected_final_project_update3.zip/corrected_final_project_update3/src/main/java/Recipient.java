public class Recipient {
    private String id;
    private String firstName;
    private String lastName;
    private String relationship;

    private GiftItem[] gifts;
    private int giftCount;

    public Recipient(String id, String firstName, String lastName, String relationship) {
        this.id = id;
        setFirstName(firstName);
        setLastName(lastName);
        setRelationship(relationship);

        gifts = new GiftItem[10];   // start capacity
        giftCount = 0;
    }

    public String getId() { return id; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getRelationship() { return relationship; }

    public GiftItem[] getGifts() {
        GiftItem[] copy = new GiftItem[giftCount];
        for (int i = 0; i < giftCount; i++) copy[i] = gifts[i];
        return copy;
    }

    public void setFirstName(String firstName) {
        this.firstName = (firstName == null) ? "" : firstName.trim();
    }

    public void setLastName(String lastName) {
        this.lastName = (lastName == null) ? "" : lastName.trim();
    }

    public void setRelationship(String relationship) {
        this.relationship = (relationship == null) ? "" : relationship.trim();
    }

    public void addGift(GiftItem gift) {
        if (gift == null) return;

        if (giftCount == gifts.length) {
            GiftItem[] bigger = new GiftItem[gifts.length * 2];
            for (int i = 0; i < gifts.length; i++) bigger[i] = gifts[i];
            gifts = bigger;
        }

        gifts[giftCount++] = gift;
    }

    public void removeGiftById(String giftId) {
        if (giftId == null) return;

        int index = -1;
        for (int i = 0; i < giftCount; i++) {
            if (gifts[i] != null && giftId.equals(gifts[i].getId())) {
                index = i;
                break;
            }
        }
        if (index == -1) return;

        for (int i = index; i < giftCount - 1; i++) {
            gifts[i] = gifts[i + 1];
        }
        gifts[giftCount - 1] = null;
        giftCount--;
    }

    public GiftItem findGiftById(String giftId) {
        if (giftId == null) return null;

        for (int i = 0; i < giftCount; i++) {
            if (gifts[i] != null && giftId.equals(gifts[i].getId())) {
                return gifts[i];
            }
        }
        return null;
    }

    public double getTotalPlannedCost() {
        double total = 0;
        for (int i = 0; i < giftCount; i++) {
            if (gifts[i] != null) total += gifts[i].getPrice();
        }
        return total;
    }

    public double getTotalSpent() {
        double total = 0;
        for (int i = 0; i < giftCount; i++) {
            if (gifts[i] instanceof PurchasedItem) {
                total += gifts[i].getPrice();
            }
        }
        return total;
    }

    public boolean isValid() {
        return id != null && !id.trim().isEmpty()
                && firstName != null && !firstName.trim().isEmpty()
                && lastName != null && !lastName.trim().isEmpty();
    }

    @Override
    public String toString() {
        return "Recipient{id='" + id + "', firstName='" + firstName + "', lastName='" + lastName
                + "', relationship='" + relationship + "', giftCount=" + giftCount + "}";
    }
}
