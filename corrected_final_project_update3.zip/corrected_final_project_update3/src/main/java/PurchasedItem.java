public class PurchasedItem extends GiftItem {
    private String purchaseDate;      // YYYY-MM-DD
    private String paymentMethod;
    private boolean wrapped;

    public PurchasedItem(String id, String name, double price, String store, String notes,
                         String purchaseDate, String paymentMethod) {
        super(id, name, price, store, notes);
        setPurchaseDate(purchaseDate);
        setPaymentMethod(paymentMethod);
        this.wrapped = false;
    }

    public String getPurchaseDate() { return purchaseDate; }
    public String getPaymentMethod() { return paymentMethod; }
    public boolean isWrapped() { return wrapped; }

    public void setPurchaseDate(String purchaseDate) {
        this.purchaseDate = (purchaseDate == null) ? "" : purchaseDate.trim();
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = (paymentMethod == null) ? "" : paymentMethod.trim();
    }

    public void setWrapped(boolean wrapped) {
        this.wrapped = wrapped;
    }

    @Override
    public String toString() {
        return "PurchasedItem{id='" + id + "', name='" + name + "', price=" + price
                + ", store='" + store + "', notes='" + notes + "', purchaseDate='" + purchaseDate
                + "', paymentMethod='" + paymentMethod + "', wrapped=" + wrapped + "}";
    }
}
