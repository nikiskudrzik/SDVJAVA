public class WishlistItem extends GiftItem {
    private int priority;         // 1 (high) to 5 (low)
    private boolean purchased;

    public WishlistItem(String id, String name, double price, String store, String notes, int priority) {
        super(id, name, price, store, notes);
        setPriority(priority);
        this.purchased = false;
    }

    public int getPriority() { return priority; }
    public boolean isPurchased() { return purchased; }

    // validate 1..5
    public void setPriority(int priority) {
        if (priority < 1) this.priority = 1;
        else if (priority > 5) this.priority = 5;
        else this.priority = priority;
    }

    public void setPurchased(boolean purchased) {
        this.purchased = purchased;
    }

    @Override
    public String toString() {
        return "WishlistItem{id='" + id + "', name='" + name + "', price=" + price
                + ", store='" + store + "', notes='" + notes + "', priority=" + priority
                + ", purchased=" + purchased + "}";
    }
}
