public class GiftPlannerManagerTest {
    public static void main(String[] args) {
        System.out.println("=== GiftPlannerManager Tests ===");

        GiftPlannerManager mgr = new GiftPlannerManager("giftplanner_data.txt");

        Recipient a = new Recipient("R1", "Alex", "Kim", "Family");
        a.addGift(new WishlistItem("W1", "Sweater", 30.0, "Old Navy", "Size M", 2));
        a.addGift(new PurchasedItem("P1", "Candles", 18.0, "Bath & Body Works", "", "2026-12-02", "Card"));

        Recipient b = new Recipient("R2", "Taylor", "Lee", "Friend");
        b.addGift(new WishlistItem("W2", "Board Game", 25.0, "Target", "", 3));

        mgr.addRecipient(a);
        mgr.addRecipient(b);

        System.out.println("Overall planned: " + mgr.getOverallPlannedCost());
        System.out.println("Overall spent: " + mgr.getOverallSpent());

        try {
            mgr.saveToFile();
            System.out.println("Saved to file OK.");

            GiftPlannerManager mgr2 = new GiftPlannerManager("giftplanner_data.txt");
            mgr2.loadFromFile();
            System.out.println("Loaded from file OK.");

            System.out.println("Loaded recipients: " + mgr2.getRecipients().length);
            System.out.println("Loaded overall planned: " + mgr2.getOverallPlannedCost());
            System.out.println("Loaded overall spent: " + mgr2.getOverallSpent());
        } catch (Exception e) {
            System.out.println("File test failed: " + e.getMessage());
        }

        System.out.println("=== Done ===");
    }
}
