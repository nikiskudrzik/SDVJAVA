public class RecipientTest {
    public static void main(String[] args) {
        System.out.println("=== Recipient Tests ===");

        Recipient r = new Recipient("R1", "Sam", "Jordan", "Friend");
        System.out.println("Recipient created: " + r);
        System.out.println("Valid? " + r.isValid());

        r.addGift(new WishlistItem("W1", "Book", 15.00, "Amazon", "Hardcover", 1));
        r.addGift(new PurchasedItem("P1", "Mug", 12.50, "Target", "Red", "2026-12-05", "Cash"));

        System.out.println("Total planned: " + r.getTotalPlannedCost());
        System.out.println("Total spent: " + r.getTotalSpent());

        GiftItem found = r.findGiftById("P1");
        System.out.println("Find gift P1: " + (found != null ? found : "NOT FOUND"));

        r.removeGiftById("W1");
        System.out.println("After remove W1, total planned: " + r.getTotalPlannedCost());

        System.out.println("=== Done ===");
    }
}
