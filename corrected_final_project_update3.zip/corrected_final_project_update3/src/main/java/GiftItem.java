public abstract class GiftItem {
    protected String id;
    protected String name;
    protected double price;
    protected String store;
    protected String notes;

    public GiftItem(String id, String name, double price, String store, String notes) {
        this.id = id;
        setName(name);
        setPrice(price);
        setStore(store);
        setNotes(notes);
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public double getPrice() { return price; }
    public String getStore() { return store; }
    public String getNotes() { return notes; }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            this.name = "";
        } else {
            this.name = name.trim();
        }
    }

    // validate price >= 0
    public void setPrice(double price) {
        if (price < 0) {
            this.price = 0;
        } else {
            this.price = price;
        }
    }

    public void setStore(String store) {
        this.store = (store == null) ? "" : store.trim();
    }

    public void setNotes(String notes) {
        this.notes = (notes == null) ? "" : notes.trim();
    }

    public boolean isValid() {
        return id != null && !id.trim().isEmpty()
                && name != null && !name.trim().isEmpty()
                && price >= 0;
    }

    @Override
    public String toString() {
        return "GiftItem{id='" + id + "', name='" + name + "', price=" + price
                + ", store='" + store + "', notes='" + notes + "'}";
    }
}
