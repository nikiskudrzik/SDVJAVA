import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class Exercise15_07 extends Application {

    @Override
    public void start(Stage primaryStage) {
        Circle circle = new Circle(80);
        circle.setStroke(Color.BLACK);
        circle.setFill(Color.WHITE);

        StackPane pane = new StackPane(circle);

        pane.setOnMousePressed(e -> circle.setFill(Color.BLACK));
        pane.setOnMouseReleased(e -> circle.setFill(Color.WHITE));

        Scene scene = new Scene(pane, 300, 300);
        primaryStage.setTitle("Exercise15_07");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
