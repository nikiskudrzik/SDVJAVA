import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Exercise14_01 extends Application {

    @Override
    public void start(Stage primaryStage) {
        GridPane pane = new GridPane();

        // Create 4 ImageViews (same size so grid looks even)
        pane.add(createImageView("Images/flag1.gif"), 0, 0);
        pane.add(createImageView("Images/flag2.gif"), 1, 0);
        pane.add(createImageView("Images/flag6.gif"), 0, 1);
        pane.add(createImageView("Images/flag7.gif"), 1, 1);

        Scene scene = new Scene(pane);
        primaryStage.setTitle("Exercise14_01");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private ImageView createImageView(String fileName) {
        ImageView imageView = new ImageView(new Image(fileName));
        imageView.setFitWidth(300);      // adjust if you want smaller/larger
        imageView.setFitHeight(200);
        imageView.setPreserveRatio(true);
        return imageView;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
